
import java.io.FileOutputStream;

public class Main {
	public static void main(String[] args) {
		try {
			String marcaModelo = "NOTEBOOK - DELL";
			String numeroEtiqueta = "4D7A9519512E3";

			PrinterApplet applet = new PrinterApplet();
			byte[] codigoDeBarras = applet.gerarCodigoDeBarras("SCA SQNOT082", marcaModelo, numeroEtiqueta);

			FileOutputStream fos = new FileOutputStream("/home/javaflores/Desktop/teste.png");
			fos.write(codigoDeBarras);
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
