

import java.applet.Applet;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.print.PrinterJob;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.SimpleDoc;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.MediaPrintableArea;

import org.krysalis.barcode4j.impl.code128.Code128Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.tools.UnitConv;

public class PrinterApplet extends Applet {
	private static final long serialVersionUID = -119388798970166122L;
	private static final String IMPRESSORA = "brother";

	public void init() {
		String marcaModelo = getParameter("MarcaModelo");
		String numeroEtiqueta = getParameter("NumeroEtiqueta");
		int larguraEtiqueta = Integer.parseInt(getParameter("LarguraEtiqueta"));
		int alturaEtiqueta = Integer.parseInt(getParameter("AlturaEtiqueta"));

		imprimir(marcaModelo, numeroEtiqueta, larguraEtiqueta, alturaEtiqueta);
	}

	protected void imprimir(String marcaModelo, String numeroEtiqueta, int larguraEtiqueta, int alturaEtiqueta) {
		try {
			String hostName = InetAddress.getLocalHost().getHostName().toUpperCase();
			PrintService impressora = recuperarImpressora();

			if (impressora != null) {
				DocPrintJob job = impressora.createPrintJob();
				byte[] codigoDeBarras = gerarCodigoDeBarras("SCA " + hostName, marcaModelo, numeroEtiqueta);

				Doc doc = new SimpleDoc(codigoDeBarras, DocFlavor.BYTE_ARRAY.PNG, null);
				PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
				pras.add(new Copies(1));
				pras.add(new MediaPrintableArea(0, 0, larguraEtiqueta, alturaEtiqueta, 1000));
				job.print(doc, pras);

				fecharJanela();
			} else {
				exibirAlerta(hostName + " - Impressora não encontrada");
			}
		} catch (Exception e) {
			exibirAlerta("Erro ao imprimir: " + e.toString());
			e.printStackTrace();
		}
	}

	private void fecharJanela() {
		try {
			getAppletContext().showDocument(new URL("javascript:window.close()"));
		} catch (Exception localException) {
		}
	}

	private void exibirAlerta(String alerta) {
		try {
			getAppletContext().showDocument(new URL("javascript:alert(\"" + alerta + "\")"));
		} catch (Exception e) {
			System.out.println(alerta);
		}
	}

	private PrintService recuperarImpressora() {
		for (PrintService ps : PrinterJob.lookupPrintServices()) {
			if (ps.getName().toLowerCase().indexOf("brother") >= 0)
				return ps;
		}
		return null;
	}

	public byte[] gerarCodigoDeBarras(String cabecalho, String marcaModelo, String numeroEtiqueta) throws IOException {
		Font font = new Font("Courier New", 0, 11);
		int dpi = 150;

		Code128Bean bean = new Code128Bean();
		bean.setBarHeight(10.0D);
		bean.setModuleWidth(UnitConv.in2mm(2.0F / dpi));
		bean.setFontName(font.getFontName());
		bean.setFontSize(2.0D);

		BitmapCanvasProvider canvas = new BitmapCanvasProvider(dpi, 12, false, 0);

		bean.generateBarcode(canvas, numeroEtiqueta);
		canvas.finish();

		BufferedImage barcode = canvas.getBufferedImage();

		FontMetrics metrics = barcode.createGraphics().getFontMetrics(font);
		int height = metrics.getHeight();

		BufferedImage image = new BufferedImage(Math.max(barcode.getWidth(), Math.max(metrics.stringWidth(cabecalho),
				metrics.stringWidth(marcaModelo))), barcode.getHeight() + height * 2 + 5, 1);

		Graphics2D graphics = image.createGraphics();
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, image.getWidth(), image.getHeight());

		graphics.setColor(Color.BLACK);
		graphics.setFont(font);
		graphics.drawString(cabecalho, (image.getWidth() - metrics.stringWidth(cabecalho)) / 2, height);
		graphics.drawString(marcaModelo, (image.getWidth() - metrics.stringWidth(marcaModelo)) / 2, height * 2);

		graphics.drawImage(barcode, 0, height * 2 + 5, null);

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(image, "png", baos);

		return baos.toByteArray();
	}
}
