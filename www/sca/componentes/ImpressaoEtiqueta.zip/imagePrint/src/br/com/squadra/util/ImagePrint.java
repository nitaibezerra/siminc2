package br.com.squadra.util;

import java.applet.Applet;
import java.awt.print.PrinterJob;
import java.io.File;
import java.net.InetAddress;
import java.net.URL;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.print.DocFlavor;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.SimpleDoc;
import javax.print.attribute.Attribute;
import javax.print.attribute.AttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;
import javax.print.attribute.standard.JobName;
import javax.print.attribute.standard.MediaPrintableArea;

/**
 * Classe responsável por imprimir uma etiqueta a partir de uma imagem PNG.
 * 
 * @author Ricardo da Silva Flores[ricardo.flores@squadra.com.br]
 * 
 */
public class ImagePrint extends Applet {

	private static final long serialVersionUID = -119388798970166122L;
	private static final String IMPRESSORA = "brother";

	public String mensagemImpressao = "Impressão realizada com sucesso.";

	public boolean isSucesso = false;

	@Override
	public void init() {

		String caminhoImagem = this.getParameter("caminhoImagem");
		int larguraEtiqueta = Integer.parseInt(this.getParameter("LarguraEtiqueta"));
		int alturaEtiqueta = Integer.parseInt(this.getParameter("AlturaEtiqueta"));
		boolean removerArquivo = Boolean.parseBoolean(this.getParameter("removerArquivo"));

		imprimir(caminhoImagem, larguraEtiqueta, alturaEtiqueta, removerArquivo);
	}

	public void imprimir(String caminhoImagem, int larguraEtiqueta, int alturaEtiqueta, boolean removerArquivo) {

		try {

			if (caminhoImagem == null || caminhoImagem.equals("")) {
				executarFuncaoJavascript(false, "Parametro da Imagem não encontrada.");
				return;
			}

			URL url = new URL(caminhoImagem);

			String hostName = InetAddress.getLocalHost().getHostName().toUpperCase();

			PrintService impressora = recuperarImpressora();

			if (impressora != null) {

				PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
				pras.add(new Copies(1));
				pras.add(new JobName("Impressão de Etiqueta - " + hostName, null));
				pras.add(new MediaPrintableArea(0, 0, larguraEtiqueta, alturaEtiqueta, MediaPrintableArea.MM));

				impressora.createPrintJob().print(new SimpleDoc(url, DocFlavor.URL.PNG, null), pras);

				if (removerArquivo) {
					try {
						new File(caminhoImagem).delete();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

				String nomeImpressora = substringAfterLast(impressora.getName(), "\\");

				// Mensagem de sucesso concatenada com o nome da impressora.
				String mensagemSucesso = "Etiqueta enviada para: " + nomeImpressora;

				// Caso o nome da impressora nao possa ser recuperada, utilizar a mensagem padrao.
				if (isEmpty(nomeImpressora) && nomeImpressora.length() <= 6) {
					mensagemSucesso = "Impressão realizada com sucesso.";
				}

				mensagemImpressao = mensagemSucesso;
				isSucesso = true;

			} else {
				mensagemImpressao = "Impressora Brother não encontrada.";

			}
		} catch (PrintException e) {
			mensagemImpressao = "Erro ao imprimir. Verifique se a impressora está offline ou desligada.";
			e.printStackTrace();
		} catch (Exception e) {
			mensagemImpressao = "Erro ao imprimir.";
			e.printStackTrace();
		}

		executarFuncaoJavascript(isSucesso, mensagemImpressao);
	}

	/**
	 * Método responsável por executar uma funcao fora da applet.
	 * 
	 * @param isSucesso
	 *            Valor boleano do sucesso da impressao.
	 * @param mensagem
	 *            Mensagem da impressao.
	 */
	private void executarFuncaoJavascript(boolean isSucesso, String mensagem) {
		try {

			StringBuilder funcaoJS = new StringBuilder("javascript:validarImpressao(");
			funcaoJS.append(isSucesso);
			funcaoJS.append(",\'");
			funcaoJS.append(mensagem);
			funcaoJS.append("\');");

			getAppletContext().showDocument(new URL(funcaoJS.toString()));

		} catch (Exception e) {
			System.out.println("Falha ao chamar função javascript.");
		}
	}

	/**
	 * Método responsável por recuperar a impressora a ser impressa.
	 * 
	 * @return Retorna a impressoras brother.
	 */
	private PrintService recuperarImpressora() {

		SortedMap<String, PrintService> mapaDeImpressoras = recuperarImpressoraBrother();

		if (mapaDeImpressoras.isEmpty()) {
			return null;
		}

		// Descomentar o codigo abaixo, caso queira exibir no console as impressoras recuperadas.
		// for (Entry<String, PrintService> impressora : mapaDeImpressoras.entrySet()) {
		// System.out.println("Fila: " + impressora.getKey() + " Nome: " + impressora.getValue());
		// }

		// Retorna a primeira impressora do mapa, pois é ela que terá a menor fila de impressao.
		return mapaDeImpressoras.get(mapaDeImpressoras.firstKey());
	}

	/**
	 * Método responsável por recuperar as impressoras brother.
	 * 
	 * @return Retorna o mapa de impressoras brother ordenadas pela fila de impressao.
	 */
	private SortedMap<String, PrintService> recuperarImpressoraBrother() {

		SortedMap<String, PrintService> mapaDeImpressoras = new TreeMap<String, PrintService>();

		// Percorre lista de impressoras
		for (PrintService ps : PrinterJob.lookupPrintServices()) {

			// Recuperando somente as impressoras com o nome Brother.
			if (ps.getName().toLowerCase().indexOf(IMPRESSORA) < 0) {
				continue;
			}

			// Recupera os atributos da impressora.
			AttributeSet att = ps.getAttributes();

			// Insere na chave do mapa de impressoras o valor da quantidade de arquivos em fila
			// e a respectiva impressora
			for (Attribute a : att.toArray()) {

				// É neste atributo que é armazenada o valor da fila de impressao da impressora.
				if ("QueuedJobCount".equals(a.getCategory().getSimpleName())) {
					mapaDeImpressoras.put(att.get(a.getClass()).toString(), ps);
				}
			}

		}
		return mapaDeImpressoras;
	}

	/**
	 * Método responsável por retornar o valor da string depois do separador.
	 * 
	 * @param str
	 *            string
	 * @param separator
	 *            separador
	 * @return Retorna o valor da string depois do separador.
	 */
	private String substringAfterLast(String str, String separator) {
		if (isEmpty(str)) {
			return str;
		}
		if (isEmpty(separator)) {
			return "";
		}
		int pos = str.lastIndexOf(separator);
		if (pos == -1 || pos == (str.length() - separator.length())) {
			return "";
		}
		return str.substring(pos + separator.length());
	}

	/**
	 * Método responsável por verificar se uma string é nula ou vazia.
	 * 
	 * @param str
	 *            Valor da String.
	 * @return Retorna true se a string for nula ou estiver vazia.
	 */
	public boolean isEmpty(String str) {
		return str == null || str.length() == 0;
	}

}