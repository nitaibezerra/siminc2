package br.com.squadra.util;

public class Main {
	
	public static void main(String[] args) {
		
		System.out.println("Iniciando impressao");
		
		ImagePrint imagePrint = new ImagePrint();
		imagePrint.imprimir("http://10.220.6.177/cracha.png", 200, 200, false);
		
		System.out.println("Fim da impressao");
		
	}

}
